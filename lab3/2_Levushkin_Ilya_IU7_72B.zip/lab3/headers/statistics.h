#pragma once

#include "server.h"

using namespace std;

void append_statistics(string ip_addr, string extension);
void save_statistics_in_txt_file(void);
